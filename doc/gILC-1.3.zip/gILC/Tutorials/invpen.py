# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 15:38:40 2011

@author: u0057542
"""
from plant import *
import random

class invpen(plant):
    
    def __init__(self):        
        self.nx = 2
        self.noisestd = 0.0

    # Define System Dynamics
    #=======================
    def f(self,xk,uk):
    #---------------
        I = 0.006
        m = 0.5
        L = 0.3
        c = 0.1
        Ts = 1/500.0
        #------
        xkp1 = [xk[0] + Ts*xk[1],\
                xk[1] + (Ts/(I+m*L**2))*(-c*xk[1] - 9.81*m*L*sin(xk[0]) + uk[0]),\
               ]            
        return xkp1
    #---------------
    def h(self,xk,uk):
        #---------------
        y = [xk[0],\
            ]
        y[0] += random.gauss(0.0,self.noisestd)
        return y
    #=======================
