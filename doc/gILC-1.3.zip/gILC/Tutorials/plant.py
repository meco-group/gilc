# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 15:29:40 2011

@author: u0057542
"""

from numpy import *

class plant:
    
        def simout(self,xinit,u):
            N = u.shape[1]
            x = zeros((self.nx,N))            
            y = zeros((len(self.h(xinit,u[:,0])),N))
            x[:,0] = xinit
        
            for k in range(N-1):
                x[:,k+1] = self.f(x[:,k],u[:,k])
                y[:,k] = self.h(x[:,k],u[:,k])
            y[:,N-1] = self.h(x[:,N-1],u[:,k])

            return y
            
        def simstates(self,xinit,u):
            N = u.shape[1]
            x = zeros((self.nx,N)) 
            x[:,0] = xinit
        
            for k in range(N-1):
                x[:,k+1] = self.f(x[:,k],u[:,k])
            
            return x
            
        def sim(self,xinit,u):
            y = self.simout(xinit,u)
            states = self.simstates(xinit,u)
            
            return (states,y)
            
        def simssout(self,u,periods):
            ut = tile(u,(1,periods))    # Repeat the input for 'periods' times

            N = u.shape[1]
            Nt = periods*N
            xt = zeros((len(self.f(zeros((self.nx)),u[:,0])),Nt))            
            yt = zeros((len(self.h(zeros((self.nx)),u[:,0])),Nt))
            y = zeros((len(self.h(zeros((self.nx)),u[:,0])),N))
            
            for k in range(Nt-1):
                xt[:,k+1] = self.f(xt[:,k],ut[:,k])
                yt[:,k] = self.h(xt[:,k],ut[:,k])
            yt[:,Nt-1] = self.h(xt[:,Nt-1],ut[:,k])
            
            for k in range(N):
                y[:,k] = yt[:,Nt-N+k]
            
            return y