/** 
*
* \example misc/range.cc
*
* Output:
* \include misc/range.log
*
*
*/
