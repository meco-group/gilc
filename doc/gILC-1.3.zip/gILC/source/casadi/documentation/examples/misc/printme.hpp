/** 
* This example looks at the printme method
*
* <a href="misc/printme.pdf">View output (PDF)</a> 
*
* \example misc/printme.py
*
* \sa
* \code
* CasADi::printme();
* \endcode
*
*/
