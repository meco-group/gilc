/** 
*
* \example misc/limitPrinting_c.cc
*
* Output:
* \include misc/limitPrinting_c.log
*
*
*/
