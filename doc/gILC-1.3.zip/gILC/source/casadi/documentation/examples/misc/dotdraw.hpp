/** 
* This example looks at the dot graph drawing functionality, only available in python.
*
* <a href="misc/dotdraw.pdf">View output (PDF)</a> 
*
* \example misc/dotdraw.py
*
*/
