/** 
*
* \example misc/all.cc
*
* Output:
* \include misc/all.log
*
*
*/
