/** 
* This example looks at a use for the Simulator class
*
* <a href="integrators/simulator.pdf">View output (PDF)</a>
*
* \example integrators/simulator.py
*
* \sa
* \code
* CasADi::Simulator();
* \endcode
*
*/
