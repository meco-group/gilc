/** 
* This example looks at the use of CasADi::Sundials::IdasIntegrator();
*
* <a href="integrators/idas.pdf">View output (PDF)</a>
*
* \example integrators/idas.py
*
* \sa
* \code
* CasADi::Sundials::IdasIntegrator();
* \endcode
*
*/
