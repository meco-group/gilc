/** 
* This example looks at a use for the ControlSimulator class
*
* <a href="integrators/controlsimulator.pdf">View output (PDF)</a>
*
* \example integrators/controlsimulator.py
*
* \sa
* \code
* CasADi::ControlSimulator();
* \endcode
*
*/
