/** 
* This example looks at a use for the Simulator class
*
* <a href="solvers/KinsolSolver.pdf">View output (PDF)</a>
*
* \example solvers/KinsolSolver.py
*
* \sa
* \code
* CasADi::Sundials::kinsolSolver();
* \endcode
*
*/
