/** 
* This example looks at a use for the IpoptSolver class
*
* <a href="solvers/ipopt.pdf">View output (PDF)</a>
*
* \example solvers/ipopt.py
*
* \sa
* \code
* CasADi::IpoptSolver();
* \endcode
*
*/
