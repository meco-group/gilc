This directory contains small code-snippets that can enhance the API docs.

The python directory gets parsed with pyreport. Both the source code and the output pdf are included in the API docs.
