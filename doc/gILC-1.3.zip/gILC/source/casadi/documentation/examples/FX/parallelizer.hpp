/** 
* This example looks at the parallelizer method
*
* <a href="FX/parallelizer.pdf">View output (PDF)</a>
*
* \example FX/parallelizer.py
*
* \sa
* \code
* CasADi::Parallelizer();
* \endcode
*
*/
