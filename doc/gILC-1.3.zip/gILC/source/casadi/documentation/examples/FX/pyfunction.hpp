/** 
* This example looks at the PyFunction class
*
* <a href="FX/pyfunction.pdf">View output (PDF)</a>
*
* \example FX/pyfunction.py
*
* \sa
* \code
* CasADi::CFunction();
* \endcode
*
*/
