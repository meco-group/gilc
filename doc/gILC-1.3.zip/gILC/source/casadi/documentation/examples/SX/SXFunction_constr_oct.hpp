/** 
* This examples demonstrates how to create an SXFunction in octave
*
* \example SX/SXFunction_constr_oct.m
*
* Output:
* \include SX/SXFunction_constr_oct.out
*
*
* \sa
* \code
*  CasADi::SXFunction();
* \endcode
*/
