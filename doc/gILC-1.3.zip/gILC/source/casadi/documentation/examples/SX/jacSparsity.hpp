/** 
* This example looks at the jacSparsity method
*
* <a href="SX/jacSparsity.pdf">View output (PDF)</a> 
*
* \example SX/jacSparsity.py
*
* \sa
* \code
* CasADi::SXfunction::jacSparsity();
* \endcode
*
*/
