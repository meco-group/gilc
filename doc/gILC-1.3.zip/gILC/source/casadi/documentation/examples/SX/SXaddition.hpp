/** 
*
* \example SX/SXaddition.cc
*
* Output:
* \include SX/SXaddition.log
*
*
* \sa
* \code
*  SX CasADi::SX::operator+(const SX &, const SX &);
* \endcode
*/
