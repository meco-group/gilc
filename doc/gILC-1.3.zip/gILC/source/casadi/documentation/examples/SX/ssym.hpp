/** 
* This example looks at the ssym method
*
* <a href="SX/ssym.pdf">View output (PDF)</a> 
*
* \example SX/ssym.py
*
* \sa
* \code
* CasADi::ssym();
* \endcode
*
*/


