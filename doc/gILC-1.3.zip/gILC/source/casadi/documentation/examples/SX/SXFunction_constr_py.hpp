/** 
* This examples demonstrates how to create an SXFunction in python
*
* <a href="SX/SXFunction_constr_py.pdf">View output (PDF)</a>
*
* \example SX/SXFunction_constr_py.py
*
*
* \sa
* \code
*  CasADi::SXFunction();
* \endcode
*/
