/** 
* This example looks at the createParent method
*
* <a href="MX/createParent.pdf">View output (PDF)</a> 
*
* \example MX/createParent.py
*
* \sa
* \code
* CasADi::createParent();
* CasADi::MX();
* \endcode
*
*/
