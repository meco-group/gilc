/** 
* This example looks at the mapping method
*
* <a href="MX/mapping.pdf">View output (PDF)</a> 
*
* \example MX/mapping.py
*
* \sa
* \code
* CasADi::MX::mapping();
* CasADi::Matrix<T>::operator[];
* \endcode
*
*/
