/** 
* This example looks at the veccat method
*
* <a href="MX/veccat.pdf">View output (PDF)</a> 
*
* \example MX/veccat.py
*
* \sa
* \code
* CasADi::veccat();
* \endcode
*
*/
