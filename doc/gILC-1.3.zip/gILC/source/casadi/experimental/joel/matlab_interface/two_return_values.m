function [varargout] = two_return_values(varargin)
  varargout{:} = swig_ref.two_return_values(varargin{:});
end
