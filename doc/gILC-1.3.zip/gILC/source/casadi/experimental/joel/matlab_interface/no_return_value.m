function no_return_value(varargin)
  swig_ref.no_return_value(varargin{:});
end
