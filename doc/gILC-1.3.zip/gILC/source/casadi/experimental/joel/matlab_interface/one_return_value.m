function [varargout] = one_return_value(varargin)
  varargout{:} = swig_ref.one_return_value(varargin{:});
end
