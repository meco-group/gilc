#ifndef TEST_SWIG_MATLAB_HPP
#define TEST_SWIG_MATLAB_HPP

// class hello{
//   public:
//     double world;
// };

static double My_variable = 3.0;
     
int fact(int n);
     
int my_mod(int x, int y);

char *get_time();

#endif // TEST_SWIG_MATLAB_HPP