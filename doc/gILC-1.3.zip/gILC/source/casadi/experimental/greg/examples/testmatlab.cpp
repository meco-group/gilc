#include <stdio.h>

#include <engdemo.hpp>

int main(void)
{
	return testmatlab();
}
