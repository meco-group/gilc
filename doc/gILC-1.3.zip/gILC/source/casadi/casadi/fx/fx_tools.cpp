/*
 *    This file is part of CasADi.
 *
 *    CasADi -- A symbolic framework for dynamic optimization.
 *    Copyright (C) 2010 by Joel Andersson, Moritz Diehl, K.U.Leuven. All rights reserved.
 *
 *    CasADi is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 3 of the License, or (at your option) any later version.
 *
 *    CasADi is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with CasADi; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include "fx_tools.hpp"
#include "../matrix/matrix_tools.hpp"
#include "../sx/sx_tools.hpp"
#include "../mx/mx_tools.hpp"
#include "../stl_vector_tools.hpp"
#include "integrator.hpp"
#include <iostream>

using namespace std;

namespace CasADi{
    
void reportConstraints(std::ostream &stream,const Matrix<double> &v, const Matrix<double> &lb, const Matrix<double> &ub, const std::string &name, double tol) { 

  casadi_assert_message(v.sparsity()==lb.sparsity(),"reportConstraints:: sparsities must match");
  casadi_assert_message(ub.sparsity()==lb.sparsity(),"reportConstraints:: sparsities must match");
  
  // Backup the formatting
  ios::fmtflags fmtflags_backup = stream.flags();
  int streamsize_backup = stream.precision();
  
  //stream.setf(ios::fixed,ios::floatfield);
  //stream.precision(8);
  
  // Check if any constraint is violated
  if ( all(v <= ub + tol) && all(v >= lb - tol) ) {
    stream << "All " << v.size() << " constraints on " << name << " are met: " << endl;
  } else {
    stream << "Problem with constraints on " << name << ": " << endl;
  }
  
  // Make a horizontal rule
  stream.width(60);
  stream.fill('-');
  stream  << "-" << endl;
  stream.fill(' ');

  // The length of the numeric fields
  int fieldlength = 10;
  // The length of the constraint visualizer strip
  int indicator_length = 15;
      
  // Loop over the elements of v
  for (int i=0;i<v.size();i++) {
  
    stream.width(5);
    stream << i << ". |   ";
         
    if (abs(lb.at(i) - ub.at(i))<=tol) {
       stream.width(fieldlength);
       stream << lb.at(i) << " ==  ";
       stream.width(fieldlength);
       stream << v.at(i) << "      ";
       stream.width(fieldlength);
       stream << " ";
       stream << "  |   ";
    } else {
      // BEGIN  - construct the constraint visualizer strip
      std::string indicator(indicator_length+2,'-');
      indicator.at(0) = (abs(v.at(i)-lb.at(i))<=tol)? 'X' : 'o';
      if (lb.at(i)==-std::numeric_limits<double>::infinity()) indicator.at(0)='8';

      indicator.at(indicator_length+1) = (abs(v.at(i)-ub.at(i))<=tol)? 'X' : 'o';
      if (ub.at(i)==std::numeric_limits<double>::infinity()) indicator.at(indicator_length+1)='8';
            
      if (v.at(i) <= (ub.at(i) + tol) && v.at(i) >= (lb.at(i) - tol)) {
        int index = (v.at(i)-lb.at(i))/(ub.at(i)-lb.at(i))*(indicator_length-1);
        index = min(max(0,index),indicator_length-1);
        indicator.at(1+index) = '=';
      }
      // END - construct the constraint visualizer strip
      
      stream.width(fieldlength);
      stream << lb.at(i) << " <=  ";
      stream.width(fieldlength);
      stream << v.at(i) << " <= ";
      stream.width(fieldlength);
      stream << ub.at(i) << "    | ";
      if (v.at(i) <= (ub.at(i) + tol) && v.at(i) >= (lb.at(i) - tol)) {
        stream  << indicator;
      }
    }

    if (v.at(i) <= (ub.at(i) + tol) && v.at(i) >= (lb.at(i) - tol)) {
    } else {
        stream  << "  VIOLATED";
    }
    stream  << endl;
  }
  
  // Make a horizontal rule
  stream.width(60);
  stream.fill('-');
  stream  << "-" << endl;
  stream.fill(' ');
  
  // Restore the formatting
  stream.setf(fmtflags_backup);
  stream.precision(streamsize_backup);
}

MXFunction parameterizeTime(FX dae) {

   // dimensionless time
   MX tau("tau");
   
   // The dae parameters augmented with t0 and tf
   MX P("P",2+dae.input(DAE_P).size());
   MX t0 = P[0];
   MX tf = P[1];
   
   std::vector<MX> dae_in(DAE_NUM_IN);
   std::vector<MX> dae_input = dae.symbolicInput();
   
   if (dae.input(DAE_T).size()==1) {
     dae_in[DAE_T]    = t0 + (tf-t0)*tau;
   }
   
   dae_in[DAE_P]    = reshape(P[range(2,2+dae.input(DAE_P).size())],dae.input(DAE_P).sparsity());
   dae_in[DAE_Y]    = dae_input[DAE_Y];
   if (dae.input(DAE_YDOT).size()>0) {
     dae_in[DAE_YDOT] = dae_input[DAE_YDOT]/(tf-t0);
   }

   std::vector<MX> ret_in(DAE_NUM_IN);
   ret_in[DAE_T]    = tau;
   ret_in[DAE_P]    = P;
   ret_in[DAE_Y]    = dae_input[DAE_Y];
   ret_in[DAE_YDOT] = dae_input[DAE_YDOT];

   std::vector<MX> ret_out(DAE_NUM_OUT);
   ret_out[DAE_RES] = (tf-t0)*dae.call(dae_in)[0];
   
   MXFunction ret(ret_in,ret_out);
   
   if (dae.isInit()) ret.init();
   
   return ret;
   
 }
 
MXFunction parameterizeTimeOutput(FX f) {
  // dimensionless time
   MX tau("tau");
   
   // The f parameters augmented with t0 and tf
   MX P("P",2+f.input(DAE_P).size());
   MX t0 = P[0];
   MX tf = P[1];
   
   std::vector<MX> f_in(DAE_NUM_IN);
   std::vector<MX> f_input = f.symbolicInput();
   
   if (f.input(DAE_T).size()==1) {
     f_in[DAE_T]    = t0 + (tf-t0)*tau;
   }
   
   f_in[DAE_P]    = reshape(P[range(2,2+f.input(DAE_P).size())],f.input(DAE_P).sparsity());
   f_in[DAE_Y]    = f_input[DAE_Y];
   if (f.input(DAE_YDOT).size()>0) {
     f_in[DAE_YDOT] = f_input[DAE_YDOT]/(tf-t0);
   }

   std::vector<MX> ret_in(DAE_NUM_IN);
   ret_in[DAE_T]    = tau;
   ret_in[DAE_P]    = P;
   ret_in[DAE_Y]    = f_input[DAE_Y];
   ret_in[DAE_YDOT] = f_input[DAE_YDOT];

   MXFunction ret(ret_in,f.call(f_in));
   
   if (f.isInit()) ret.init();
   
   return ret;


}

Matrix<double> numSample1D(FX &fx, const Matrix<double> &grid) {
  // Can be parallelized
  casadi_assert_message(fx.isInit(),"numSample1D:: supplied function must be initialized.");
  casadi_assert_message(fx.getNumInputs()>=1,"numSample1D:: supplied function must have at least one input.");
  casadi_assert_message(fx.input().size2()==1, "numSample1D:: supplied fx must have a column-matrix-like first input, but you supplied a shape " << fx.input().dimString() << ".");
  casadi_assert_message(fx.input().dense()==1, "numSample1D:: supplied fx must have dense input, but you supplied " << fx.input().dimString() << ".");
  casadi_assert_message(grid.size1()==fx.input().size1(), "numSample1D:: supplied grid has a shape " << grid.dimString() << ", but the column size does not match the column size of the supplied fx first input, which is " << fx.input().dimString() << ".");
  std::vector< Matrix<double> > ret(grid.size2());
  for (int j=0;j<grid.size2();++j) {
    fx.input().set(grid(ALL,j));
    fx.evaluate();
    ret[j] = Matrix<double>(fx.output());
  }
  return horzcat(ret);
}
    
Matrix<double> numSample1DT(FX &fx, const Matrix<double> &grid) {
  casadi_error("Not implemented yet");
}

Matrix<double> numSample2D(FX &fx, const Matrix<double> &grid) {
  casadi_error("Not implemented yet");
}


} // namespace CasADi

