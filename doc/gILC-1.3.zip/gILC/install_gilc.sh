#! /bin/bash

# Define main gILC folder
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "-----------------------------------------------------------------"
echo "This script installs gILC and all its dependancies (if necessary)"
echo "-----------------------------------------------------------------"

# Install prerequisite packages
echo " "
echo "Checking/installing prerequisite packages (password required)"
echo " "
sudo apt-get install wget subversion cmake mpich-bin gfortran libblas-dev liblapack-dev \
coinor-libipopt-dev libmumps-seq-4.9.2 python-dev python-numpy python-scipy swig1.3 --install-recommends

# Build the Casadi code

cd $DIR/source/casadi/build
cmake ..
make
make python
echo " "
echo "Installing CasADi (password required)"
sudo make install_python
echo " "
echo "CasADi succesfully installed"
echo " "
cd $DIR/source
sudo python setup.py install
echo "------------------------------"
echo "gILC was succesfully installed"
echo "------------------------------"
